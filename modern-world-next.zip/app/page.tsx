'use client';
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Sun, ShoppingCart } from "lucide-react";

const produkty = [
  {
    nazwa: "Okulary przeciwsłoneczne",
    opis: "Stylowe i lekkie, idealne na słoneczne dni.",
    cena: "79 zł",
    obrazek: "/images/okulary.jpg",
  },
  {
    nazwa: "Kapelusz plażowy",
    opis: "Chroni przed słońcem i dodaje stylu.",
    cena: "59 zł",
    obrazek: "/images/kapelusz.jpg",
  },
  {
    nazwa: "Torba plażowa",
    opis: "Pojemna i modna torba na wszystko, co potrzebne nad wodą.",
    cena: "99 zł",
    obrazek: "/images/torba.jpg",
  },
];

export default function ModernWorld() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-100 p-6">
      <header className="text-center mb-10">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-blue-800 flex justify-center items-center gap-2"
        >
          <Sun className="text-yellow-500" /> Modern World
        </motion.h1>
        <p className="text-lg text-gray-600 mt-2">
          Najlepsze akcesoria letnie dla Ciebie – styl, wygoda i jakość.
        </p>
      </header>

      <main className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {produkty.map((produkt, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.2 }}
          >
            <Card className="rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <img
                src={produkt.obrazek}
                alt={produkt.nazwa}
                className="rounded-t-2xl w-full h-48 object-cover"
              />
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold text-blue-700">
                  {produkt.nazwa}
                </h2>
                <p className="text-gray-600 mb-2">{produkt.opis}</p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-green-600">
                    {produkt.cena}
                  </span>
                  <Button className="flex gap-2 items-center">
                    <ShoppingCart size={16} /> Kup teraz
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </main>

      <footer className="mt-16 text-center text-gray-500 text-sm">
        © 2025 Modern World. Wszystkie prawa zastrzeżone.
      </footer>
    </div>
  );
}
